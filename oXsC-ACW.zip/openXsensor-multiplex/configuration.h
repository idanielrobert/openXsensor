// Fichier de configuration du module openXesnsor pour Multiplex
// !!!!   Les // indiquent que ce qui suit sur la ligne est un cmmentaire et ne doivent pas �tre supprim�
// !!! ne modifier que la valeure num�rique apr�s le libell�
// par exemple, vous pouvez modifier le chiffre 6 qui suit  'canalAltimetre'
 
#define canalAltimetre 3
#define canalVariometre 4
#define alarmeAltitude 120
#define alarmeVarioMonteeMax 500
#define alarmeVarioDescenteMax -500
 
//  !!!! NE PAS MODIFIER LES LIGNES CI-DESSOUS !!!!
#define SETUP_MULTIPLEX_DATA_TO_SEND    \  
  canalAltimetre , REL_ALTIMETER , 1 , 1 , 0 , -16384 , alarmeAltitude, \
  canalVariometre , VERTICAL_SPEED , 1 , 1 , 0, alarmeVarioDescenteMax , alarmeVarioMonteeMax